from Tkinter import start

#sort_list = ["Quick Sort", "Bubble Sort", "Insertion Sort"]
start()


